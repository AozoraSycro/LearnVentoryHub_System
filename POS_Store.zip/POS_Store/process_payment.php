<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// รับข้อมูลจาก AJAX
$cart = json_decode($_POST['cart'], true);

foreach ($cart as $item) {
    $p_ID = $item['id'];
    $quantity = $item['qty'];
    $total_price = $item['price'] * $quantity;

    // ดึงชื่อสินค้า
    $sql_product = "SELECT p_name FROM Product WHERE p_ID = '$p_ID'";
    $result_product = $conn->query($sql_product);
    $product = $result_product->fetch_assoc();
    $p_name_copy = $product['p_name']; // เก็บชื่อสินค้าลงใน p_name_copy


    // บันทึกข้อมูลการขาย
    $sql = "INSERT INTO Sales (user_id, p_ID, quantity, total_price, p_name_copy, sale_date) 
        VALUES ('$user_id', '$p_ID', '$quantity', '$total_price', '$p_name_copy', NOW())";
    $conn->query($sql);

    // อัปเดตสต็อกสินค้า
    $conn->query("UPDATE Product SET p_total = p_total - $quantity WHERE p_ID = '$p_ID'");
}

// ส่งสถานะกลับ
echo "success";
